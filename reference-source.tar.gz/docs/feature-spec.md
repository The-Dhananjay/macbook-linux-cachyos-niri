# Product specification

## Goal

Create a fast, coherent, Mac-inspired Linux desktop on CachyOS without leaving Niri. Visual polish should be consistent, while each control still performs real Linux actions and remains accessible by keyboard.

## Desktop shell

- Keep Niri's scrollable tiling, native workspaces and Wayland session.
- Make the Noctalia top bar unobtrusive and translucent over the desktop. Use a consistent compact 32 px-class panel target, legible high-quality vector/status icons, aligned spacing, and readable date/time typography.
- On the left, show app menu/title only while a real application window is focused. Show no stale app name on an empty desktop. Avoid duplicating launcher buttons; keep the explicitly selected shortcut set.
- Provide working Wi-Fi, Bluetooth, battery, audio route/volume, brightness, notifications/Focus, calendar, and Control Center interactions. Display truthful state and errors; do not report connection before audio/network backend confirms it.
- Control Center should open/close on outside click and Escape; use a translucent dark glass panel, balanced typography, and native NetworkManager/BlueZ/PipeWire state. Settings links should open the relevant real settings page, not a decorative mock screen.
- Dock is centered, translucent and lightly blurred, auto-hides when windows cover the workspace, appears on an empty desktop or bottom-edge reveal, and supports resizing/hover magnification where supported.
- Launcher/search opens on the chosen shortcut (Alt+Space in the user's prior preference), visually consistent with macOS Spotlight/Launchpad, with four useful discovery categories when pointer/trackpad moves as specified in the live setup.
- Application titlebar traffic-light controls can be provided in the shell bar for the focused app: close, workspace-based hide/restore, maximize/restore. Document that universal replacement of every app's native title bar is not possible under Niri; remove duplicate shell-supplied decorations only where the app toolkit supports it.
- Notifications use a consistent translucent style. Outside-click dismissal should work for shell panels where supported, with proper focus and accessibility.

## Lock screen and authentication

- Use a real compositor session-lock protocol and PAM-backed password verification; fail closed if the locker crashes.
- Keep a clean centered clock/date, local profile photo crop, hidden password field that reveals on first typed key without dropping that character, password fallback, and smooth video only if it stays within the available rendering budget.
- Never imitate or bypass authentication. Do not change PAM without explicit need and a tested rollback. Never commit the portrait, video, password, PAM secret, or fingerprints.
- Fingerprint unlock only if an officially supported driver successfully enrolls and matches. Preserve password fallback and require explicit review for any experimental privileged driver.

## Niri interactions and file workflow

- Configure natural-scroll/tap/gestures with native Niri input configuration when the touchpad supports them. Explicitly document app-dependent gestures and features that cannot be globally emulated.
- Windows+L locks the screen. Preserve keyboard accessibility and avoid conflicting bindings.
- In the file manager, Enter rename, Super+I properties, hidden files shortcut, and Space quick preview; Space tap toggles and hold-to-close if reliable and safely isolated.
- Screenshot toolbar on the selected screenshot shortcut supports screen/window/region capture, annotation and save destination. Screen recording uses the supported Wayland portal picker; never record audio unless requested.
- KDE Connect/Android local pairing only through a narrowly scoped local-network rule if needed. No broad network/firewall opening.

## User-named voice assistant

- At first setup ask the user what to call the assistant. Offer Friday as one option, never assume it is mandatory; support another chosen name and a no-assistant choice. Store the selected display name and wake phrase as editable user settings. Do not ask again on every run.
- English is currently preferred. Provide keyboard shortcut (Win+Shift+F) plus an optional local wake phrase based on the chosen name (for example “Hey Friday”). One continuous conversation should accept a follow-up without another mic click, and stop on “bye”, Escape, outside-click, lock, or the privacy toggle.
- New Siri-inspired compact glowing bar near the top; minimal transient mic/listening state integrated into that UI, no unrelated notification banners.
- VAD should stop soon after speech ends and start reply automatically. Faster ASR can be primary with a confidence gate and more accurate fallback; show uncertainty and ask for repetition instead of guessing. Don't promise instant/cloud-quality recognition from a local model.
- Use short fixed actions for installed apps and URLs, system volume/brightness, media, time/battery, lock, screenshot, app/window/workspace controls, safe file search, notes and timers. Route actual Linux system audio state, not assistant TTS or its output stream. Support a broad table of installed app actions, including WhatsApp when installed, instead of special-casing only YouTube.
- Launch an app once, focus an existing window when possible, and resolve installed `.desktop` entries. `Open YouTube on Brave` opens the URL using Brave. Never use shell interpolation.
- General questions use the selected local model when available; optional web search transmits only question text and links to a provider. Offline commands and local answers continue without Internet. Explain if a current answer cannot be verified.
- Automatically speak only when a non-built-in output (Bluetooth/wired/USB/HDMI) is explicitly selected and confirmed available; otherwise show text only. Never scan devices slowly on every query.
- Include female English voice as a preference, but use voices with clear licenses and avoid claiming a particular voice loaded until verified. User can turn voice output off.
- Wake word is a privacy-sensitive opt-in, local-only, visible indicator, disabled when locked. Audio stays in memory and never goes to web search/cloud ASR unless the user separately opts in.
- Command parsing is allowlisted and deterministic. Semantic model may propose, but never execute, actions. Confirm before power actions and other consequential/destructive operations. Do not enable arbitrary PC control merely because the assistant was asked to control the PC.

## Acceptance checklist

- Fresh checkout has an inventory/preview and dry-run before any live edits.
- Existing config backup can restore byte-for-byte changed files.
- Panel/launcher/dock state is live and interaction works; no stale focused-app label on desktop.
- Network/audio state reads from real backends and errors are truthful.
- Lock remains PAM-backed with keyboard entry tested and password fallback retained.
- Fingerprint remains disabled when the device/driver cannot pass enrollment + positive/negative verification.
- Friday's supported commands are table-driven; arbitrary command execution is impossible by design.
- Streaming/auto-follow-up/stop flow passes tests; local data is private and temporary recordings are removed.
- Documentation states exact tested/not-tested behavior and recovery steps.
