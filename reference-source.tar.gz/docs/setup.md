# Staged setup process

This is a one-run workflow, not a blind root installer. The agent should detect the distribution and use supported package sources; package names and APIs must be rechecked against the current repositories and upstream docs before changes. CachyOS is the reference target. Debian/Ubuntu, Fedora, Arch-family and openSUSE may be adapted where dependencies exist. NixOS and immutable systems require their native declarative workflow. If Niri is absent, install it alongside the current desktop rather than replacing the default session.

## 0. Inventory before changes

Record OS release, Niri/Noctalia/Quickshell versions, desktop apps, package source, session type, active monitors, input devices (metadata only), user units, free disk and memory. Inspect config and report proposed file diffs. Redact usernames, IDs, SSIDs, MAC/IP addresses and secrets from logs.

## 1. Establish recovery

- Create an owner-only timestamped backup of every file to edit and a manifest of original paths/checksums.
- Confirm an alternate TTY/terminal route and a known working login/lock path.
- Export current package list and user-service enablement state.
- Present one concise plan of package, file, service and privileged changes, including rollback. Then continue in the same run unless native OS authentication, a security-sensitive approval, or a user-only hardware action is required.

## 2. Install from supported sources in batches

- Use signed CachyOS repositories for Niri/Noctalia/Quickshell/tools when available.
- Check package signing and publisher for any upstream binary; do not disable signature checking.
- Avoid unofficial copr/PPAs; CachyOS is Arch-based, use supported repositories/AUR only after reviewing PKGBUILD and dependencies. Prefer official packages.
- Never auto-install model weights until disk/free RAM and license/source are verified. Show estimated download size.
- Resolve the full dependency list first, download/cache files where safe, and install packages in one transaction per package manager. Do not install one dependency at a time if they can be batched.
- Group necessary privileged filesystem/service changes into one reviewed, narrowly scoped operation. Ask for native authentication immediately before it; never collect/store the user's password. OS policy may still request authentication more than once, and the agent must not work around that policy.

## 3. Apply reversible modules

1. Niri keybind/input/layout changes in isolated config includes or minimal diffs.
2. Noctalia theme/widgets and interaction behavior.
3. User-level services for small, bounded helpers.
4. Lock surface integration, retaining logind lock, PAM verification and password fallback.
5. Friday assistant only after action API, privacy and recognition behavior are tested independently.
6. Optional peripherals (Android, fingerprint) last and only when hardware/backends confirm support.

Each module gets a `README`, install/check/disable path, checksums or manifest where useful, and its own rollback operation. Do not deploy the whole profile if the user wants a subset.

## 4. Validate before enable

- Parse/validate Niri KDL and Noctalia configuration using versions installed on the target.
- Start services manually and inspect sanitized logs before enabling autostart.
- Test commands with mocked adapters first; network/Bluetooth/volume tests must not sever access unexpectedly.
- For lock: verify wrong password rejects, correct password unlocks, keyboard first char works, lock crash fails closed, and fallback is available.
- For fingerprint: official driver only, enroll, exact positive match, non-enrolled negative rejection, then login/PAM integration review. Do not enable if any step fails.
- For assistant: run without mic/device privileges first; test no arbitrary shell path, cancellation, lock pause, temporary audio cleanup, false command rejection, system output routing, and follow-up timeout.
- Visually inspect panel, text scale, contrasting background, keyboard focus, outside click and Escape.

## 5. Roll out and recover

Enable one user service/module at a time. Keep the old config until at least one logout/login cycle and a recovery check pass. If any shell panel or lock fails, run the documented per-module rollback from a TTY and restore only the files listed in its manifest. Never remove the only working login method during a style update.

## Example manual staging commands

Commands below are examples; use only after confirming current upstream syntax and exact package names. An implementation agent must not execute these blindly.

```sh
# Read-only inspection examples
niri --version
noctalia-shell --version
systemctl --user --no-pager --type=service --state=running
```

Avoid broad update/upgrade commands in automation. Keep to the requested dependency set and the distro's recommended package workflow with a working backup/recovery path. A coding agent, downloads, hardware support and OS authorization cannot be made universally one-click across every Linux distribution.
