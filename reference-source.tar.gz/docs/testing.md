# Verification matrix

## Baseline and packaging

- [ ] CachyOS release, session, compositor and shell versions captured
- [ ] All package sources identified; signatures retained
- [ ] Disk/RAM budget checked before local AI/model installs
- [ ] Config backup manifest and dry-run reviewed

## Niri and shell

- [ ] Config parser accepts changes; unknown keys rejected before deployment
- [ ] Shell starts/reloads with no errors; existing windows/workspaces remain usable
- [ ] Empty desktop does not show a stale app title
- [ ] Control Center reflects real Wi-Fi/Bluetooth/audio state and state changes are verified
- [ ] Outside click, Escape, keyboard focus and screen scaling work
- [ ] Dock hide/reveal/resizing behavior verified with and without windows
- [ ] Color contrast and icons remain legible on light and dark wallpaper

## Lock and inputs

- [ ] System lock request and manual shortcut both engage one lock surface
- [ ] Wrong password rejected; correct password unlocks; no password appears in logs
- [ ] First printable key is not dropped; Escape clears only the UI input
- [ ] Lock stays secure after shell/helper crash
- [ ] Suspend/lid close path tested safely and timeout/inhibitor does not leave display unlocked
- [ ] Fingerprint only enabled after official support, enrollment, enrolled positive and non-enrolled negative checks; otherwise disabled
- [ ] Trackpad gestures do not interfere with Niri workspace navigation or typing

## Friday

- [ ] Supported command table maps to fixed action IDs, not shell strings
- [ ] Speech transcripts are inspected without retaining audio
- [ ] Low-confidence and out-of-domain speech prompts repeat; it performs no action
- [ ] “Open YouTube on Brave” creates/focuses one correct tab/window
- [ ] Audio volume changes actual PipeWire system sink level and leaves TTS routing independent
- [ ] Audio speech stays silent on built-in speakers if external-only setting is active
- [ ] Follow-up works once without extra click and stops on goodbye/Esc/outside/lock
- [ ] “Open Brave” does not multiply windows during startup race
- [ ] Wake detector has visible mic state, respects lock and can be paused
- [ ] Timers/notes are owner-only, bounded and removable

## Release gate

- [ ] Tests, static validation, and manual interactions recorded with exact versions/date
- [ ] No secrets or personal data in staged diff or repository history
- [ ] Rollback executed in a disposable copy or exact restore command validated
- [ ] Current-state doc clearly separates verified behavior from assumptions/limitations
- [ ] User receives concise change summary and known issues
