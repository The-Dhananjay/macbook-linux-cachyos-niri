# Architecture

```text
Niri (Wayland compositor)
  ├── Noctalia shell: bar, launcher, dock, notifications, Control Center
  ├── Quickshell lock surface: ext-session-lock-v1 + PAM verification
  ├── User systemd services: local helper daemons only where necessary
  ├── Desktop applications: GTK/Qt/app-native title bars remain app-owned
  └── Friday UI and local assistant service
        ├── Shortcut / optional local wake-word gate
        ├── microphone capture + local VAD/ASR
        ├── deterministic allowlisted intent router
        ├── typed desktop adapters (Niri, PipeWire, NetworkManager, MPRIS)
        └── local LLM for general questions; optional text-only web search
```

## Ownership boundaries

- Niri owns windows, workspaces, focus, gestures, lock integration and compositor shortcuts.
- Noctalia owns desktop shell surfaces and theme state. Widgets should query actual system services and report state rather than fabricate it.
- Quickshell owns only the custom lock surface. PAM remains the sole password authority.
- Friday owns a small explicit action API. Recognition, prompts and model output are untrusted input; only validated typed intents reach adapters.
- PipeWire/WirePlumber, NetworkManager and BlueZ remain the authorities for audio/network/Bluetooth.
- systemd user services own background lifecycle. Prefer `Restart=on-failure`, resource limits, no root, and explicit runtime permissions.

## Security boundaries

- UI components are not authorization boundaries. Revalidate in the backend before each action.
- No shell command assembled from recognized speech or model output.
- Keep wake recording buffers in memory; no debug dumps. Store notes/settings with owner-only permissions.
- User-level services get no extra groups/capabilities. Any input service requiring `/dev/uinput` must be separately isolated and documented with a disable procedure.
- Hardware biometrics are gated on upstream support and real positive/negative matching. A successful touch detection is not a successful biometric authentication.
- State-changing network and power actions need clear confirmation or explicit direct intent; lock screen and credential policy must not be weakened for appearance.
