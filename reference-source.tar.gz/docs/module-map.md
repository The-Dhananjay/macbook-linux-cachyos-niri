# Deployment map and compatibility gates

The bundle contains original reference code, not a ready-to-copy image of the owner's home directory. `setup.py stage` renders a private, user-specific working tree. It intentionally does not install packages or enable services. The implementing AI completes deployment after inspecting the target.

| Staged path | Candidate destination | Gate before enabling |
|---|---|---|
| `apps/mac-control-center` | `~/.local/share/mac-control-center` | GTK4, PyGObject, NetworkManager introspection, BlueZ, PipeWire/WirePlumber, gtk4-layer-shell and a Wayland compositor supporting layer-shell |
| `apps/mac-spotlight` | `~/.local/share/mac-spotlight` | GTK4; adapt Niri window rules and validate output scale/keyboard focus |
| `apps/mac-capture` | `~/.local/share/mac-capture` | GTK4/Cairo, Niri capture APIs, desktop portals, PipeWire, FFmpeg/GStreamer recording requirements; test portal consent before claiming recording works |
| `apps/friday` | `~/.local/share/friday` | Optional; configure chosen name, installed app lookup, microphone policy, VAD/ASR models, licensed TTS model and optional local AI. Do not enable wake listening without opt-in |
| `config/friday/*` | `~/.config/friday/` | Initial wake pause marker and editable preferences; never remove the pause marker without wake-listening opt-in |
| `bin/*` | `~/.local/bin/*` | Resolve executable paths; retain existing helpers and avoid shadowing another user's command. Install with mode 0755 |
| `profiles/shared/desktop_design.py` | `~/.local/share/mac-desktop-design/desktop_design.py` | GTK4/Gio; imported by the custom applications |
| `profiles/mac-appearance`, `mac-dock-size`, `mac-theme` | `~/.local/bin/` | Reference Niri include layout, Noctalia schema/IPC and gsettings compatibility. Adapt before copying on a different setup |
| `profiles/zzz-design-refinement.toml` | `~/.config/noctalia/` | Native Noctalia v5 TOML schema; never apply to legacy v4 JSON/Quickshell configurations |
| `noctalia-plugins/*` | `~/.local/share/noctalia/plugins/` | Matching plugin API; run `tools/render_status_icons.py` first to generate the referenced 3× PNGs; enable only after local API/identity checks |
| `lock/*` | `~/.config/quickshell/niri-mac-lock/` | Quickshell session-lock and PAM APIs, local user identity, user-selected local media, known working PAM service and recovery path; visual preview first |
| `systemd-user/*` | `~/.config/systemd/user/` | Only for systemd user sessions. Resolve package/model paths; manually start/test before enable. Use the native service manager otherwise |
| `tests/friday/*` | Keep in staging | Run against the rendered source with subprocess/device adapters mocked |

## Portable runtime resources

Binary runtimes, model weights, personal photos and video are deliberately absent. Resolve each resource for the target architecture from its official publisher or signed distribution repositories. Record URL, license, checksum, size and verification in the local report. Never transplant another laptop's native libraries or CPU-specific backend.

- GTK4/PyGObject/Cairo, NetworkManager GI, gtk4-layer-shell GI/native library, Rsvg (icon generation).
- PipeWire/WirePlumber/Pulse-compatible tools, BlueZ, NetworkManager, brightness control supported by the installed shell.
- Screenshot recording: compatible portal backends and FFmpeg/GStreamer with hardware acceleration only after a real encoder test.
- Optional assistant: Vosk native library and English model, whisper.cpp CLI and English models, NumPy/ONNX Runtime, Silero VAD, Piper and a licensed English voice, optional Ollama/model. Inspect the source resource paths and adapt them; no automatic opaque downloads are performed by `setup.py`.
- Lock: Quickshell/Qt multimedia; use an original gradient/still background when the user has not supplied a video/photo. Never invent a user's portrait or fetch Apple assets without checking their terms.
- File preview: stock file-manager preview support first. Hold-to-preview needs an explicitly reviewed, narrowly scoped input bridge; never grant broad input-device access just to reproduce an animation.
- Android: KDE Connect only after explicit device trust/pairing. Fingerprint: inspect exact support; experimental privileged drivers are not bundled or automatically enabled.

## Desktop compatibility

The reference uses CachyOS, Niri and native Noctalia v5. Niri blur/geometry extensions and Noctalia plugin APIs may vary across packaged builds. Probe and validate capabilities; omit unsupported effect keys and use a solid/translucent fallback. Do not replace the user's compositor or shell just to hide a compatibility error.

For Debian/Ubuntu, Fedora, Arch-family and openSUSE, verify actual package availability/version rather than guessing names. NixOS and immutable Fedora systems use their native declarative/layered workflow. If no supported package exists, explain the tradeoff and review the official source-build recipe; do not silently add third-party repositories.

Current primary references: [Niri getting started](https://github.com/niri-wm/niri/blob/main/docs/wiki/Getting-Started.md), [Noctalia docs](https://docs.noctalia.dev/), [Quickshell setup](https://quickshell.org/docs/guide/install-setup/), [GTK Wayland](https://docs.gtk.org/gtk4/wayland).
