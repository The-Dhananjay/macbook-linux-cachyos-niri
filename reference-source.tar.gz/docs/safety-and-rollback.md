# Safety, privacy and rollback

## Non-negotiable safety rules

- No password, sudo secret, API token, SSH private key, Wi-Fi credential, browser cookie, fingerprint template, voice clip, portrait or private wallpaper in Git.
- Use `.gitignore`, a pre-push secret scan and review staged diffs. Keep models, package archives and generated audio out of repository history.
- Avoid raw dumps from `env`, browser profiles, process command lines, D-Bus, keyring, journal or network config.
- No shell from speech text. Never construct `sh -c`, `bash -c`, eval, or command templates using recognized speech or model output.
- Use fixed application desktop-file IDs and argument arrays. For URLs allow only recognized schemes/hosts or a visible confirmation.
- Web search receives text only and only when enabled. Explain that the search provider sees query text.
- Voice wake is opt-in, locally processed, visibly indicated, paused on lock, cancellable, and bounded in time. Prefer in-memory frames with no audio logs.
- Keep all auth through PAM/logind. Never read, store, log, or transmit passwords.
- No broad privileges or blanket group membership. Hardware service permissions must be specific and removable.
- If official fingerprint support is unavailable, disable biometrics. Do not install a proprietary Windows DLL inside root authentication service unless a future decision explicitly accepts the risk; this device failed isolated capture.

## Backup manifest

For each changed path record: original path, backup path, owner/mode, SHA-256, package/service dependency, reason, validation result and reverse command. Backups must be outside Git and mode `0700` directories with files `0600` unless execution requires a different owner mode.

## Rollback order

1. Stop/disable newly added Friday or widget user services.
2. Remove only added Noctalia widget/theme overrides, preserving unrelated user changes.
3. Restore original Niri config from manifest, then validate it before reloading/restarting Niri.
4. Restore previous locker routing while unlocked; keep PAM unchanged.
5. Undo any explicit firewall/network/udev/system-service change with its own backup and exact scope.
6. Verify login, lock/unlock, network, audio, and existing apps. Do not delete backups until the user confirms stability.

Never use `git clean -fdx`, `rm -rf ~/.config`, or a broad system reset as a rollback method.
