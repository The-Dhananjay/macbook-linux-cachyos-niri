# Installed desktop design system

This document records the macOS-inspired design refinement installed on the reference Niri desktop on 2026-11-19. It distinguishes implementation from evidence and native platform constraints.

## Installed changes

| Area | Implementation |
|---|---|
| Menu/status bar | 32 logical pixel profile, consistent Inter Variable typography, clean clock spacing; status vector artwork rasterized at 3× logical resolution |
| Dock | Light translucent background, compositor blur, smart auto-hide, moderate magnification, active indicators; persistent 32–80 logical pixel resize slider |
| Control Center | Existing real NetworkManager/BlueZ/PipeWire controls preserved; matching battery panel reads kernel-reported capacity/status; Appearance & Motion controls added |
| Materials | Shared GTK material controller for Control Center, launcher, screenshot toolbar and assistant; light/dark adaptation, keyboard focus and pressed/disabled states |
| Popovers | Custom launcher, Control Center and assistant coordinate transient ownership over the session bus; opening one dismisses another; existing Escape/outside-click handlers retained |
| Notifications/OSD | Neutral palette, shared border/opacity treatment; grouping remains enabled; opaque accessibility settings apply through the shell settings API |
| Motion | Existing native Niri spring/easing configuration preserved; assistant color stops interpolate continuously at an approximately 30 Hz UI update interval instead of jumping every two seconds |
| Accessibility | Reduced motion disables Niri/shell/GTK animation and Dock magnification. Reduced transparency uses solid shell panels, opaque custom cards and disables relevant compositor blur. Combined mode adds high-contrast custom panel borders/text |
| Lock visuals | Unified login/clock font family; reduced motion uses the existing still wallpaper instead of loading video. Session-lock/PAM authentication logic remains unchanged |
| Screenshot toolbar | Existing capture/recording backend preserved; shared material, focus and control-state styling applied. Toolbar stays independent of transient coordination so another popup cannot terminate recording |
| Persistence | Appearance/resize commands use the shell settings API, which takes precedence over profile TOML files. Appearance changes validate configuration and restore captured settings on failure |

## User controls

Open Control Center → Appearance & Motion. Choose Standard, Reduce Motion, opaque materials, combined accessibility, Light/Dark, or adjust Dock size.

Equivalent commands installed on the reference machine:

```sh
mac-appearance standard
mac-appearance reduce-motion
mac-appearance reduce-transparency
mac-appearance accessible
mac-theme light
mac-theme dark
mac-dock-size 48
```

The final baseline is Standard, Dark, 48 logical pixel Dock icons. Smart hide remains enabled.

## Reusable source

- `profiles/zzz-design-refinement.toml`: baseline style geometry.
- `profiles/shared/desktop_design.py`: shared GTK CSS, theme monitoring and transient coordination.
- `profiles/mac-appearance`: reversible motion/material settings.
- `profiles/mac-dock-size`: bounded persistent size setting.
- `profiles/mac-theme`: synchronized light/dark appearance.

The Python module requires GTK 4/Gio and is integrated into the existing custom applications at startup. The appearance command targets the reference Niri include layout and Noctalia schema; inspect those before installing elsewhere. These files are not a universal unattended installer for arbitrary Linux desktops.

## Verification evidence

- Modified Python sources parsed successfully.
- Niri and Noctalia configuration validation passed.
- Live shell reads verified effective animation, material/opacity and Dock size settings.
- Accessible/standard mode switching and restoration passed, including a real failed-config rollback during development.
- Launcher and Control Center startup and coordinated dismissal passed without Python/GTK CSS errors.
- Screenshot toolbar started without taking a screenshot or starting a recording during that check.
- Assistant idle interface opened without microphone capture or a command; its appearance was inspected.
- Light/dark and combined-accessibility panels were inspected in local screenshots; low-contrast light-mode custom icons were corrected.
- LockFace loaded in an automatically closing, nonlocking preview with password input disabled. No new password/fingerprint authentication test was performed.
- Existing lock-event, hidden-window restore and assistant wake services remained active.

No frame-time instrumentation, every-app compatibility matrix, or claim of identical Apple rendering is implied by these checks. Existing Wi-Fi join, Bluetooth audio, password/fingerprint unlock and capture/recording user confirmations remain historical evidence; they were not repeated by disconnecting devices or locking the user's working session in this refinement.

## Native platform boundaries

App-exported menus remain app/toolkit-dependent; existing shortcut/fallback integration is retained where no native menu is exported. The working Niri bar controls remain the supported window-control approach. Universal in-app Apple traffic-light decorations, Apple-only haptics/Touch ID hardware behavior and Apple's private animation/rendering system are not supplied by a Linux theme. Proprietary Apple fonts/media are not redistributed.

## Primary research references

- [Materials](https://developer.apple.com/design/human-interface-guidelines/materials)
- [Typography](https://developer.apple.com/design/human-interface-guidelines/typography)
- [Motion](https://developer.apple.com/design/human-interface-guidelines/motion)
- [Color](https://developer.apple.com/design/human-interface-guidelines/color)
- [Windows](https://developer.apple.com/design/human-interface-guidelines/windows)
- [Popovers](https://developer.apple.com/design/human-interface-guidelines/popovers)
- [Notifications](https://developer.apple.com/design/human-interface-guidelines/notifications)
- [Accessibility](https://developer.apple.com/design/human-interface-guidelines/accessibility)

Linux dimensions/timings are implementation choices, not measurements of Apple's private UI.

## Recheck — 2026-11-19

- 43 assistant regression tests passed against copies of the installed source. This covers parsing, bounded volume actions, browser duplicate suppression, route-cache behavior, cancellation and conversation lifecycle; it does not establish live speech-recognition accuracy. Synthetic recognition fixtures were used for the recognition tests.
- All six Control Center views built successfully with live read-only network/audio/brightness state. Slider dispatch was mocked; no volume, brightness, network or pairing change was made.
- Screenshot framing preserved synthetic window pixels with white padding and shadow. All five toolbar modes and consent-portal source wiring passed checks with actual recording requests mocked.
- Startup and coordinated dismissal checks passed. Live settings, icon dimensions, shortcut targets and source syntax were checked. No failed user services were present.
- Fixed two settings edge cases: failed Dock resizing now restores the effective saved size as well as the profile; appearance toggles preserve subsequent user animation edits. Both fixes passed isolated failure/preservation tests and live settings validation.
- Corrected light-mode launcher category icons and prevented unrelated network updates from rebuilding the appearance slider mid-interaction.
- Full physical touchpad behavior, live microphone accuracy, Bluetooth reconnect/audio, new lock authentication and actual screen-recording consent were not repeated. Existing confirmations remain historical evidence.
