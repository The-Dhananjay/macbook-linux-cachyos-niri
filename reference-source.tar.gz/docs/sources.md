# Upstream references

Verified on 2026-11-17. Recheck before implementation because CachyOS and the desktop shell are rolling/current projects.

- CachyOS supported desktop environments, including Niri: https://wiki.cachyos.org/installation/desktop_environments/
- CachyOS Niri and Noctalia package/config notes: https://wiki.cachyos.org/configuration/desktop_environments/niri/
- Niri configuration overview: https://github.com/niri-wm/niri/wiki/Configuration%3A-Overview
- Niri project/manual: https://github.com/niri-wm/niri
- Noctalia documentation: https://docs.noctalia.dev/
- Noctalia shell configuration (versioned docs): https://docs.noctalia.dev/noctalia/v5.5.0/configuration/shell/
- Noctalia control center, themes, bar and widget docs: https://docs.noctalia.dev/noctalia/
- Quickshell docs: https://quickshell.org/docs/
- systemd user services/manual: https://www.freedesktop.org/software/systemd/man/latest/systemd.service.html
- PipeWire configuration/reference: https://docs.pipewire.org/
- libfprint officially supported devices: https://fprint.freedesktop.org/supported-devices.html
- Noctalia privacy/telemetry docs: https://docs.noctalia.dev/noctalia/v5.5.0/configuration/shell/
- GitHub private repository visibility: https://docs.github.com/en/repositories/creating-and-managing-repositories/about-repositories

Fingerprint support must be checked against the target sensor and current upstream supported-device list. A different machine's experimental result is not a compatibility guarantee.

Do not copy commands from a doc without verifying the target release, permissions and rollback consequences. Official documentation establishes interface behavior; it does not authorize broad privilege changes.
