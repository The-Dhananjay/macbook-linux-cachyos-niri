#!/usr/bin/env python3
"""Render original vector status assets at 3× without changing logical sizes."""
import argparse
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('directory',type=Path);args=p.parse_args()
import cairo,gi
gi.require_version('Rsvg','2.0')
from gi.repository import Rsvg
for source in args.directory.glob('*-sharp.svg'):
 width=50 if source.name.startswith('battery-') else 25;height=25
 surface=cairo.ImageSurface(cairo.FORMAT_ARGB32,width*3,height*3);context=cairo.Context(surface)
 handle=Rsvg.Handle.new_from_data(source.read_bytes());rect=Rsvg.Rectangle();rect.x=rect.y=0;rect.width=width*3;rect.height=height*3
 handle.render_document(context,rect);surface.write_to_png(str(source.with_suffix('.png')))
print('Rendered 3× status assets')
