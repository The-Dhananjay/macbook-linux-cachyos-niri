"""Shared local GTK desktop appearance and transient-panel coordination."""
import json
from pathlib import Path
from gi.repository import Gdk, Gio, GLib, Gtk
PREFERENCES = Path.home()/'.local/state/mac-appearance/preferences.json'
INTERFACE = 'local.DesktopDesign.Transient'
OBJECT = '/local/DesktopDesign/Transient'
DESKTOP_SETTINGS = Gio.Settings.new('org.gnome.desktop.interface')

def preferences():
    try:
        value=json.loads(PREFERENCES.read_text())
        return value if isinstance(value,dict) else {}
    except (OSError, ValueError):
        return {}

def reduced_motion():
    settings=Gtk.Settings.get_default()
    return settings is not None and not settings.get_property('gtk-enable-animations')

def light_appearance():
    return DESKTOP_SETTINGS.get_string('color-scheme')=='prefer-light'

def themed_svg(path):
    path=Path(path)
    candidate=path.with_name(path.stem+'-light.svg')
    return candidate if light_appearance() and candidate.exists() else path

class Design:
    def __init__(self, app, close, transient=True):
        self.app=app;self.close=close;self.transient=transient;self.identity=app.get_application_id()
        self.provider=Gtk.CssProvider();self.monitor=None;self.settings=None
        Gtk.StyleContext.add_provider_for_display(Gdk.Display.get_default(),self.provider,Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION+1)
        PREFERENCES.parent.mkdir(parents=True,exist_ok=True)
        self.monitor=Gio.File.new_for_path(str(PREFERENCES.parent)).monitor_directory(Gio.FileMonitorFlags.NONE,None)
        self.monitor.connect('changed',lambda *_:self.reload())
        self.settings=DESKTOP_SETTINGS
        self.settings.connect('changed::color-scheme',self.theme_changed)
        self.bus=Gio.bus_get_sync(Gio.BusType.SESSION,None)
        self.subscription=self.bus.signal_subscribe(None,INTERFACE,'Opened',OBJECT,None,Gio.DBusSignalFlags.NONE,self.other_opened)
        self.app.connect('window-added',self.window_added)
        self.reload()
    def theme_changed(self,*_):
        self.reload()
        if hasattr(self.app,'build') and getattr(self.app,'window',None) and self.app.window.get_visible():
            GLib.idle_add(lambda:(self.app.build(),False)[1])
    def window_added(self,_app,window):
        window.connect('map',lambda *_:self.claim(window))
    def claim(self,window):
        if not self.transient:return
        # Never coordinate invisible input shields or authentication windows.
        if window.has_css_class('friday-shield') or window.has_css_class('mac-dismiss-shield'):return
        self.bus.emit_signal(None,OBJECT,INTERFACE,'Opened',GLib.Variant('(s)',(self.identity,)))
    def other_opened(self,_bus,_sender,_path,_interface,_signal,params):
        if self.transient and params.unpack()[0]!=self.identity:
            self.close()
    def reload(self):
        prefs=preferences();mode=prefs.get('mode','standard');opaque=mode in ('reduce-transparency','accessible')
        light=self.settings.get_string('color-scheme')=='prefer-light'
        fg='#202124' if light else '#f5f5f7';secondary='#55565c' if light else '#c6c6cc'
        surface='#ededf0' if light else '#343438';border='#babac0' if light else '#66666d'
        alpha='1' if opaque else '.92'
        css=f'''
window.mac-controls,window.spotlight,window.capture,window.friday {{color:{fg};}}
.glass,.friday-card,.toolbar,window.spotlight .pill,window.spotlight .results-panel {{background:alpha({surface},{alpha});border-color:alpha({border},.7);}}
.title,.heading,.answer,.app-name,window.spotlight entry,window.friday entry,window.mac-controls entry {{color:{fg};}}
.small,.muted,.hint,.section,.category-shortcut {{color:{secondary};}}
window.mac-controls .flat,window.mac-controls button.card,window.spotlight .category-button,window.spotlight .result {{color:{fg};}}
window.spotlight .app-name,window.spotlight .keycap,window.spotlight .chip,window.spotlight .empty,window.spotlight .search-icon {{color:{fg};}}
window.spotlight .hint,window.spotlight .category-shortcut {{color:{secondary};}}
window.friday entry.siri-entry {{color:{fg};caret-color:{fg};}}
window.capture .tool {{color:{fg};}}
button:focus-visible {{outline:2px solid #3478f6;outline-offset:2px;}}
button:disabled {{opacity:.45;}}
'''
        if light:
            css+='button.card,.card {background:alpha(#000000,.035);} .flat:hover,.category-button:hover {background:alpha(#000000,.08);} .off {background:alpha(#000000,.10);color:#303034;} scale trough {background:alpha(#000000,.16);} scale highlight {background:#3478f6;} .error {color:#af241c;}\n'
        if mode in ('reduce-motion','accessible'):
            css+='* {transition:none;animation:none;}\n'
        if opaque:
            css+='window.spotlight .results-panel,.glass,.friday-card,.toolbar {box-shadow:none;}\n'
        if prefs.get('high_contrast'):
            css+='button,entry,.glass,.friday-card,.toolbar {border:2px solid '+fg+';} .small,.muted,.hint,.section {color:'+fg+';} button:focus-visible {outline-width:3px;}\n'
        self.provider.load_from_data(css.encode())
