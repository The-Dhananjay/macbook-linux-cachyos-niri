"""Failure injection and preservation checks with isolated HOME and fake shell APIs."""
import json,os,subprocess,sys,tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]/'profiles'
FAKE='''#!/usr/bin/python3
import json,os,sys
from pathlib import Path
h=Path.home();state=h/'.local/state/noctalia/settings.toml';state.parent.mkdir(parents=True,exist_ok=True)
try:data=json.loads(state.read_text())
except (OSError,ValueError):data={'dock.icon_size':48}
command=Path(sys.argv[0]).name;args=sys.argv[1:]
if command=='gsettings':
 if args[0]=='get':print('true')
elif command=='noctalia':
 if args[:2]==['msg','config-get']:print(data.get(args[2],48))
 elif args[:2]==['msg','config-set']:
  try:data[args[2]]=json.loads(args[3])
  except ValueError:data[args[2]]=args[3]
  state.write_text(json.dumps(data))
 elif args[:2]==['msg','config-reload'] and os.environ.get('FAIL_RELOAD_ONCE') and not (h/'failed-once').exists():
  (h/'failed-once').touch();raise SystemExit(1)
'''
with tempfile.TemporaryDirectory(prefix='mac-settings-recheck-') as folder:
 h=Path(folder);bin=h/'bin';bin.mkdir()
 for command in ['gsettings','niri','noctalia']:
  p=bin/command;p.write_text(FAKE);p.chmod(0o755)
 env={**os.environ,'HOME':str(h),'PATH':str(bin)+':'+os.environ['PATH']}
 cfg=h/'.config/niri';(cfg/'cfg').mkdir(parents=True);(cfg/'config.kdl').write_text('// base\n')
 anim=cfg/'cfg/animation.kdl';custom='// user-specific animation edit\nanimations {\n}\n';anim.write_text(custom)
 def execute(name,*args,fail=False):
  r=subprocess.run([sys.executable,str(ROOT/name),*args],env={**env,**({'FAIL_RELOAD_ONCE':'1'} if fail else {})},capture_output=True,text=True)
  return r
 assert execute('mac-appearance','standard').returncode==0
 assert anim.read_text()==custom,'Standard mode erased custom animation edits'
 assert execute('mac-appearance','reduce-motion').returncode==0
 assert 'off' in anim.read_text()
 assert execute('mac-appearance','standard').returncode==0
 assert anim.read_text()==custom,'Reduce-motion restoration lost custom edits'
 print('PASS: custom animation edits survive Standard and reduced-motion round trip')
 target=h/'.config/noctalia/zzz-dock-size.toml';target.parent.mkdir(exist_ok=True);target.write_text('[dock]\nicon_size = 48\n')
 old=target.read_text();r=execute('mac-dock-size','56',fail=True)
 assert r.returncode!=0,'Injected reload failure was ignored'
 assert target.read_text()==old,'Dock profile was not restored'
 state=json.loads((h/'.local/state/noctalia/settings.toml').read_text())
 assert state['dock.icon_size']==48,'Effective Dock setting was not restored'
 print('PASS: failed Dock reload restores profile AND effective saved size')
 assert execute('mac-dock-size','500').returncode!=0
 assert execute('mac-dock-size','48').returncode==0
 print('PASS: invalid Dock size is rejected; valid update succeeds')
