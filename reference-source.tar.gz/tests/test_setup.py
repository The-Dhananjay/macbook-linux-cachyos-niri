"""Portable setup checks: staging never touches the live desktop."""
import hashlib,io,json,os,shutil,subprocess,sys,tarfile,tempfile,unittest
from pathlib import Path
REPO=next(p for p in Path(__file__).resolve().parents if (p/'setup.py').exists())
class SetupTests(unittest.TestCase):
 def setUp(self):
  self.temp=tempfile.TemporaryDirectory();self.base=Path(self.temp.name);self.repo=self.base/'repo';self.repo.mkdir();self.home=self.base/'home';self.home.mkdir()
  for name in ['setup.py','reference-source.tar.gz','SOURCE_MANIFEST.json']:shutil.copy2(REPO/name,self.repo/name)
  self.env={**os.environ,'HOME':str(self.home)}
 def tearDown(self):self.temp.cleanup()
 def call(self,*args,ok=True):
  result=subprocess.run([sys.executable,str(self.repo/'setup.py'),*args],env=self.env,capture_output=True,text=True,timeout=20)
  self.assertEqual(result.returncode==0,ok,result.stderr+result.stdout)
  return json.loads(result.stdout) if ok else result
 def test_custom_name_and_opt_in_defaults(self):
  self.call('configure','--assistant-name','Nova');self.call('stage');stage=self.repo/'.setup-state/staged'
  self.assertIn('hey nova',(stage/'apps/friday/wake.py').read_text())
  self.assertIn('Ask Nova',(stage/'apps/friday/friday.py').read_text())
  self.assertTrue((stage/'config/friday/wake-paused').exists())
  self.assertIn('self.web.set_active(False)',(stage/'apps/friday/friday.py').read_text())
  self.assertFalse((self.home/'.config/noctalia').exists())
 def test_no_assistant(self):
  self.call('configure','--no-assistant');self.call('stage');stage=self.repo/'.setup-state/staged'
  self.assertFalse((stage/'apps/friday').exists());self.assertFalse((stage/'bin/friday').exists())
  self.assertFalse(any((stage/'systemd-user').glob('friday*')))
 def test_invalid_name(self):self.call('configure','--assistant-name','bad; command',ok=False)
 def test_corrupt_bundle(self):
  with (self.repo/'reference-source.tar.gz').open('ab') as out:out.write(b'corruption')
  self.call('check',ok=False)
 def test_unsafe_archive_path(self):
  archive=self.repo/'reference-source.tar.gz'
  with tarfile.open(archive,'w:gz') as tar:
   entry=tarfile.TarInfo('../escape');entry.size=1;tar.addfile(entry,io.BytesIO(b'x'))
  manifest={'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files':{'../escape':{'sha256':hashlib.sha256(b'x').hexdigest(),'bytes':1}}}
  (self.repo/'SOURCE_MANIFEST.json').write_text(json.dumps(manifest));self.call('extract',ok=False)
  self.assertFalse((self.repo/'.setup-state/escape').exists())
 def test_checkpoint_restore_and_user_edit_guard(self):
  target=self.home/'.config/niri/example.kdl';target.parent.mkdir(parents=True);target.write_text('original')
  ident=self.call('checkpoint',str(target))['checkpoint'];target.write_text('installed');self.call('seal',ident)
  target.write_text('user edit');self.call('restore',ident,ok=False);self.assertEqual(target.read_text(),'user edit')
  target.write_text('installed');self.call('restore',ident);self.assertEqual(target.read_text(),'original')
 def test_checkpoint_rejects_other_files(self):self.call('checkpoint',str(self.home/'.ssh/id_key'),ok=False)
if __name__=='__main__':unittest.main()
